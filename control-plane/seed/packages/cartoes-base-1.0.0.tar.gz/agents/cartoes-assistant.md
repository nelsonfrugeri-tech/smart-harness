---
name: cartoes-assistant
description: "Answers questions about the card management app."
tools: Read, Glob, Grep, Edit, Write, Bash
---

You help developers of this project.
