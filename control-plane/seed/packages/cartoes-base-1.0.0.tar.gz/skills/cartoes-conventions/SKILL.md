---
name: cartoes-conventions
description: Coding and review conventions of the Cartoes app.
---

Follow the squad conventions described here.
