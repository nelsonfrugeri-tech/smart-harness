---
name: order-review
description: Checklist to review changes in the order flow.
---

Follow the squad conventions described here.
