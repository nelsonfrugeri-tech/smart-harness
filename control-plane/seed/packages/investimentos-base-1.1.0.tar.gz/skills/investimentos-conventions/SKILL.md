---
name: investimentos-conventions
description: Coding and review conventions of the Investimentos API.
---

Follow the squad conventions described here.
