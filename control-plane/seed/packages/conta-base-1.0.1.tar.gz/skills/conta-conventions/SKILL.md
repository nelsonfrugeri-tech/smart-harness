---
name: conta-conventions
description: Coding and review conventions of the Conta Digital backend.
---

Follow the squad conventions described here.
