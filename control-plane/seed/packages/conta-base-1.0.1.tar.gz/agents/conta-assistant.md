---
name: conta-assistant
description: "Answers questions about the digital account backend."
tools: Read, Glob, Grep, Edit, Write, Bash, mcp__plugin_conta-base_github__*
---

You help developers of this project.
