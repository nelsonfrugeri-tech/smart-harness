---
name: conta-assistant
description: Answers questions about the digital account backend.
tools: [read, edit, shell, mcp:github]
---

You help developers of this project.
