---
name: code-review
description: Reviews a diff for correctness, tests and security before a pull request.
---

Follow the squad conventions described here.
